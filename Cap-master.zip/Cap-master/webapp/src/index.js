import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import '@fortawesome/fontawesome-free/css/all.min.css'; 
import 'bootstrap-css-only/css/bootstrap.min.css'; 
import 'mdbreact/dist/css/mdb.css';
import Reducer from './redux/Reducer';
import {createStore,applyMiddleware} from 'redux';
import {Provider} from 'react-redux';

const  logger = store =>{
    return next =>{
        return action =>{
            console.log('[Middleware] dispatching',action);
            console.log('[Middleware] before state',store.getState())
            const result = next(action);
            console.log('[Middleware] after state',store.getState());
            return result;
        }
    }
}

const store = createStore(Reducer,applyMiddleware(logger));
ReactDOM.render(<Provider store={store}> <App /></Provider>, document.getElementById('root'));


