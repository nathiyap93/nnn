import React, { Component } from "react";
import {
  MDBNavbar, MDBNavbarBrand, MDBNavbarNav, MDBNavItem, MDBNavLink, MDBNavbarToggler, MDBCollapse, MDBDropdown,
  MDBDropdownToggle, MDBDropdownMenu, MDBDropdownItem, MDBIcon
} from "mdbreact";
import { NavLink } from 'react-router-dom';
import { connect } from 'react-redux';

class Header extends Component {
  constructor(props) {
    super(props);
  }
  state = {
    isOpen: false
  };

  toggleCollapse = () => {
    this.setState({ isOpen: !this.state.isOpen });
  }

  render() {
    console.log("prrops in  header", this.props);
    // console.log("chhek",this.props.location.pathname === to);
    console.log("to", this.props.children);

    return (
      <div>
        <MDBNavbar color="default-color" dark expand="md">
          <MDBNavbarBrand>
            <strong className="white-text">Outreach FMS</strong>
          </MDBNavbarBrand>
          <MDBNavbarToggler onClick={this.toggleCollapse} />
          <MDBCollapse id="navbarCollapse3" isOpen={this.state.isOpen} navbar>
            <MDBNavbarNav left>
              <MDBNavItem >

                <MDBNavLink exact to="/dashboard"  > <i className="fa fa-plus-square" /> &nbsp;DashBoard</MDBNavLink>
              </MDBNavItem>
              <MDBNavItem >

                <MDBNavLink exact to="/event"> <i className="fa fa-arrow-circle-right" /> &nbsp; Events</MDBNavLink>
              </MDBNavItem>
              <MDBNavItem>

                <MDBNavLink to="/report"> <i className="fa fa-file-excel" /> &nbsp; Reports</MDBNavLink>
              </MDBNavItem>
              <MDBNavItem>
                <MDBDropdown>
                  <MDBDropdownToggle nav caret>
                    <i className="fa fa-cog" /> &nbsp;
                  <div className="d-none d-md-inline">Configuration</div>
                  </MDBDropdownToggle>
                  <MDBDropdownMenu className="dropdown-default">
                    <NavLink to="/role"><MDBDropdownItem>Roles</MDBDropdownItem></NavLink>
                    <NavLink to="/questions"><MDBDropdownItem>Feedback Questions</MDBDropdownItem> </NavLink>
                  </MDBDropdownMenu>
                </MDBDropdown>
              </MDBNavItem>
            </MDBNavbarNav>
            <MDBNavbarNav right>
              <MDBNavItem>
                <MDBDropdown>
                  <MDBDropdownToggle nav caret>
                    <MDBIcon icon="user" /> &nbsp; {this.props.Users.name}
                  </MDBDropdownToggle>
                  <MDBDropdownMenu className="dropdown-default">
                    <MDBDropdownItem href="/">Log Out</MDBDropdownItem>
                  </MDBDropdownMenu>
                </MDBDropdown>
              </MDBNavItem>
            </MDBNavbarNav>
          </MDBCollapse>
        </MDBNavbar>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    Users: state.userData

  };
};
export default connect(mapStateToProps, null)(Header);