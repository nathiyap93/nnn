import React from 'react';
import Axios from 'axios';
const EventDetails = (props) => {
  console.log("pprops in evennt details", props.location.eventData);



  return (
    <div>

      <div>
        <h1 className="event-title">ACTIONS</h1>
        <div className="event-row mb-3">

          <div className="col-xl-3 col-sm-6 py-2">
            <div className="card text-white bg-info h-100">
              <div className="card-body bg-info">
                <div className="rotate">
                  <i className="fa fa-envelope fa-4x"></i>
                </div>
                <h6 className="text"><b>Email Reminder!</b></h6>
                <p>Sit back and relax while app  send email
             <a href="#" className="btn btn-primary">Send Email</a></p>
              </div>
            </div>
          </div>

          <div className="col-xl-3 col-sm-6 py-2">
            <div className="card text-black bg-warning h-100">
              <div className="card-body ">
                <div className="rotate">
                  <i className="fa fa-lightbulb fa-4x"></i>
                </div>
                <h6 className="text"><b>Future Implementation!</b></h6>
                <p>This Placeholder can be use to add any  action in  future</p>
              </div>
            </div>
          </div>


        </div>

      </div>

      <div>
        <h1 className="event-title">EVENT & BENEFICIARY DETAILS</h1>
        <div style={{ display: "flex", width: "150%" }}>
          <div className="col-lg-4 col-md-6">
            <div className="card text-center">
              <div className=" card-header info-color white-text">
                <p style={{ float: "left" }}><b>Id: {props.location.eventData.event_id}</b></p>
                <p style={{ float: "right" }}><b>Date: {props.location.eventData.event_date}</b></p>
              </div>
              <div className="card-body">
                <h4 className="card-title">{props.location.eventData.event_name}</h4>
                <p className="card-text">{props.location.eventData.event_description}</p>

              </div>
              <div className="card-footer text-muted grey-color ">
                <p style={{ float: "left" }}><b>Status: <text style={{ backgroundColor: "green", color: "white" }}> {props.location.eventData.status}</text></b></p>
                <p style={{ float: "right" }}><b>Category:{props.location.eventData.category}</b></p>
              </div>
            </div>
          </div>

          <div className="col-lg-4 col-md-6">
            <div className="card text-center">
              <div className=" card-header info-color white-text">
                <p style={{ float: "left" }}><b>Location: {props.location.eventData.base_location}</b></p>
                <p style={{ float: "right" }}><b>Council:{props.location.eventData.council_name}</b></p>
              </div>
              <div className="card-body">
                <h4 className="card-title">{props.location.eventData.beneficiary_name}</h4>
                <p className="card-text">{props.location.eventData.venueture_address}</p>

              </div>
              <div className="card-footer text-muted gray-color ">
                <p style={{ float: "left" }}><b>Feedback: <text style={{ backgroundColor: "orange", color: "white" }}>4</text></b></p>
                <p style={{ float: "right" }}><b>Avg Rating:<text style={{ backgroundColor: "blue", color: "white" }}>4</text></b></p>
              </div>
            </div>
          </div>
        </div>

      </div>

      <div>
        <div style={{ display: "flex", width: "100%", padding: "1rem 0rem" }}>
          <div className="col-lg-4 col-md-6">
            <div className="card text-center">
              <div className=" card-header info-color white-text">
                <p style={{ float: "left" }}><b>PARTICIPATED</b></p>

              </div>
              <div className="card-body" >
                <div style={{ border: "1px solid Green", marginTop: "10px" }}>
                  <p className="card-text" style={{ textAlign: "left" }}>Rating : 5 <br />
                    Likes : nice <br />
                    Dislike : travel <br />
                  </p>
                </div>
                <div style={{ border: "1px solid Green", marginTop: "10px" }}>
                  <p className="card-text" style={{ textAlign: "left" }}>Rating : 4<br />
                    Likes : dance <br />
                    Dislike : travel <br />
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6">
            <div className="card text-center">
              <div className=" card-header info-color white-text">
                <p style={{ float: "left" }}><b>NOT PARTICIPATED</b></p>

              </div>
              <div className="card-body" >
                <div style={{ border: "1px solid Green" }}>
                  <p className="card-text">Unexpected Offical Work</p>
                </div>
              </div>

            </div>
          </div>

          <div className="col-lg-4 col-md-6">
            <div className="card text-center">
              <div className=" card-header info-color white-text">
                <p style={{ float: "left" }}><b>UNREGISTERED</b></p>

              </div>
              <div className="card-body">
                <div style={{ border: "1px solid Green" }}>
                  <p className="card-text">Family work</p>
                </div>
              </div>

            </div>
          </div>
        </div>

      </div>

      <div>
        <div style={{ display: "flex", width: "150%" }}>
          <div className="col-lg-4 col-md-6">
            <div className="card text-center">
              <div className=" card-header info-color white-text">
                <p style={{ float: "left" }}><b>STATISTICS</b></p>

              </div>
              <div className="card-body">
                <table className="statistic-table">
                  <thead>
                    <th>AVERAGE RATING</th>
                    <th>VOLUNTEERS</th>
                    <th>VOULUNTEERING HOURS</th>
                    <th>OVERALL HOURS</th>
                    <th>TRAVEL HOURS</th>
                    <th>LIVES IMPACTED</th>
                  </thead>
                  <tbody>
                    <td>4.5</td>
                    <td>{props.location.eventData.total_no_of_volunteers}</td>
                    <td>{props.location.eventData.total_volunteer_hours}</td>
                    <td>{props.location.eventData.overall_volunteer_hours}</td>
                    <td>{props.location.eventData.total_travel_hours}</td>
                    <td>{props.location.eventData.lives_impacted}</td>
                  </tbody>
                </table>

              </div>

            </div>
          </div>

          <div className="col-lg-4 col-md-6">
            <div className="card text-center">
              <div className=" card-header info-color white-text">
                <p style={{ float: "left" }}><b>POC DETAILS</b></p>

              </div>
              <div className="card-body">
                <table className="statistic-table">
                  <thead>
                    <th>#</th>
                    <th>EMPLOYEE ID</th>
                    <th>NAME</th>
                    <th>CONTACT NUMBER</th>

                  </thead>
                  <tbody>
                    <td>1</td>
                    <td>{props.location.eventData.poc_id}</td>
                    <td>{props.location.eventData.poc_name}</td>
                    <td>{props.location.eventData.poc_contact}</td>


                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>


    </div>

  )
}
export default EventDetails