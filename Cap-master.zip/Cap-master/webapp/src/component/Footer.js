import React from 'react';
const Footer = () => {
    return (
        <div>
            <p>©2020 Outreach Feedback Management System -Cognizant All Rights Reserved</p>
        </div>
    )
}

export default Footer