import React from 'react';
import Axios from 'axios';
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBModalFooter,
  MDBIcon,
  MDBCardHeader,
  MDBBtn,
  MDBInput
} from "mdbreact";
import {connect} from 'react-redux';
import * as actionCreators  from '../redux/Action';

class Login extends React.Component {
    
    constructor(props){
     super(props);
     this.state = {
        email: "",
        password: "",
        isAdmin : false
        
      };
    }

    componentDidMount = () => {
      console.log('componentDidMount called');
      
  }
    
    formSubmitHandler (event){
        event.preventDefault();
        console.log("email:",this.state.email);
        console.log("password:",this.state.password);
       
        let credentials={
          emailId:this.state.email,
          password:this.state.password
        }
        Axios.post(`http://localhost:8081/login`,credentials)
        .then(res =>{
        console.log("res val:",res);
        console.log("res:",res.data);
        if(res.status=='200'){
          this.props.onLogin(res.data)
          this.props.history.push({pathname: '/dashboard',user:res.data})
         
        }else if(res.status=='401'){
          console.log("unathorised")
        }else{
          console.log("intenal Server error")
        }
       
        }).catch(function (error) {
          console.log("unathorised:",error);
        });
        // if(this.state.email === 'admin@gmail.com' && this.state.password === 'admin'){
                  
        //   this.props.history.push({pathname: '/dashboard'})
        // }
        // else{
        //    this.props.Users.filter(user =>{
        //      if(user.email===this.state.email)
        //      this.props.history.push({pathname: '/user',userinfo: { user}})
        //    })
         
        // }
    }
    changeEmailHandler =(event)=>{
        this.setState({email:event.target.value});
    }

    changePasswordHandler =(event)=>{
        this.setState({password:event.target.value});
    }

   

    render(){
        return (
         
<MDBContainer>
      <MDBRow>
        <MDBCol md="6">
          <MDBCard>
            <MDBCardBody>
              <MDBCardHeader className="form-header deep-blue-gradient rounded">
                <h3 className="my-3">
                  <MDBIcon icon="lock" /> <b>Cognizant </b> Outreach
                  <h6>FeedBack Management System</h6>
                </h3>
              </MDBCardHeader>
              <form>
                <div className="grey-text">
                  <MDBInput
                    label="Type your email"
                    icon="envelope"
                    group
                    type="email"
                    validate
                    error="wrong"
                    success="right"
                    value={this.state.email} onChange ={this.changeEmailHandler.bind(this)}
                  />
                  <MDBInput
                    label="Type your password"
                    icon="lock"
                    group
                    type="password"
                    validate
                    value={this.state.password} onChange ={this.changePasswordHandler.bind(this)}
                  />
                </div>

              <div className="text-center mt-4">
                <MDBBtn
                  color="light-blue"
                  className="mb-3"
                  type="submit"
                  onClick={this.formSubmitHandler.bind(this)}
                >
                  Login
                </MDBBtn>
              </div>
              </form>
              <MDBModalFooter>
                <div className="font-weight-light">
                  <p>Not a member? <a href="#">Sign Up</a></p>
                 <a  href="#"> <p>Forgot Password?</p></a>
                </div>
              </MDBModalFooter>
            </MDBCardBody>
          </MDBCard>
        </MDBCol>
      </MDBRow>
    </MDBContainer>

        )
    }
}


 const mapDispatchToProps = dispatch =>{
  return{
    onLogin: (val) => {dispatch(actionCreators.login(val))}
    
  };
};   

export default connect(null,mapDispatchToProps) (Login);


