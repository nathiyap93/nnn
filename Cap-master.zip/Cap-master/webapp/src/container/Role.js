import React from 'react';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table-plus';
import Axios from 'axios';
class Role extends React.Component{
    constructor(props){
        super(props);
        this.state={
            data:[]
        }
    }

    componentDidMount = () => {
        //console.log('componentDidMount called in dashboard',this.props.history.location.user.token);
        // let  header = {
        //     Authorization: "Bearer "+this.props.history.location.user.token,
        
           
          Axios.get('http://localhost:9040/event', { headers: {'Content-Type': 'application/json'}}).then(res =>{
          console.log("res val:",res);
          console.log("res:",res.data);
          if(res.status=='200'){
           this.userTableHandler(res.data)
              
          }
          }).catch(function (error) {
            console.log("error:",error);
          });
        
    }

    userTableHandler =(userdata)=>{
        userdata.filter((user) =>{
             console.log("val:",user.body);
            
              this.state.data.push(user.body)
             
             return(
              user
            
             )
          })
          this.setState({data:this.state.data})
       }
   

    render(){
        return(
            <div  style={ {margin: '15px'}}>
                <div >
                <h1 className="event-title"><b>ASSIGN PMO</b></h1>
                <div className="add-pmo">
                    Employee Email  <input type="text" style={ {marginLeft: '200px',width:'25%'}} placeholder="Enter Email Address" />
                     <button className="add-pmo-button">ADD PMO</button>
                      <button className="remove-pmo-button"><b>REMOVE PMO</b></button>
                </div>
            </div>

             <div>
                <div >
                <h1 className="event-title">PMO USERS</h1>
                <div className="add-pmo">
                <BootstrapTable data={ this.state.data }  pagination options={ this.options }>
                    <TableHeaderColumn dataField='emailId' className="event-table-th">Email</TableHeaderColumn>
                    <TableHeaderColumn dataField='firstName' isKey className="event-table-th">First Name</TableHeaderColumn>
                    <TableHeaderColumn dataField='lastName'  className="event-table-th">Last Name</TableHeaderColumn>
                </BootstrapTable>
                </div>
            </div> 


            </div>
            </div>
        )
    }
}
export default Role;