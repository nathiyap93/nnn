import React from 'react';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table-plus';
import Axios from 'axios';
class Event extends React.Component{
    constructor(props){
     super(props);
     this.options = {
        defaultSortName: 'base_location',  // default sort column name
        defaultSortOrder: 'desc'  // default sort order
      };
     this.state={
         data:[]
            
         
     }

    }

    componentDidMount = () => {
      //console.log('componentDidMount called in dashboard',this.props.history.location.user.token);
      // let  header = {
      //     Authorization: "Bearer "+this.props.history.location.user.token,
      
         
        Axios.get('http://localhost:9040/event', { headers: {'Content-Type': 'application/json'}}).then(res =>{
        console.log("res val:",res);
        console.log("res:",res.data);
        if(res.status=='200'){
         this.eventTableHandler(res.data)
            
        }
        }).catch(function (error) {
          console.log("error:",error);
        });
      
  }
    eventDetailsHandler =(eventId)=>{
       console.log("eeveent detaiils",eventId);
       console.log("url:","'http://localhost:9040/event/"+eventId+"'");
       
       Axios.get('http://localhost:9040/event/'+eventId, { headers: {'Content-Type': 'application/json'}}).then(res =>{
        console.log("event details res val:",res);
        console.log("event details res data:",res.data);
        if(res.status=='200'){
         this.props.history.push({pathname: '/details/'+eventId,eventData:res.data})
            
        }
        }).catch(function (error) {
          console.log("error:",error);
        });
      
    }
     eventTableHandler =(eventdata)=>{
      eventdata.filter((event) =>{
           console.log("val:",event.body);
           console.log("eventid:",event.body.eventId);
            this.state.data.push(event.body)
           
           return(
              event
          
           )
        })
        this.setState({data:this.state.data})
     }

     buttonFormatter=(cell, row)=>{
        console.log("row",row.event_id);
        
      return <button  className="btn btn-primary"  onClick={()=>this.eventDetailsHandler(row.event_id)}>view</button>;
    }
    render(){ console.log("event propss",this.props);
        return(
            <div>
               <div>
               <h1 className="event-title">ACTIONS</h1>
               
               <div className="event-row mb-3">

               <div className="col-xl-3 col-sm-6 py-2">
                <div className="card text-white bg-info h-100">
                        <div className="card-body bg-info">
                            <div className="rotate">
                                <i className="fa fa-envelope fa-4x"></i>
                            </div>
                            <h6 className="text"><b>Email Reminder!</b></h6>
                            <p>Sit back and relax while app  send email
                            <a href="#" className="btn btn-primary">Send Email</a></p>
                        </div>
                    </div>
                </div>

                <div className="col-xl-3 col-sm-6 py-2">
                <div className="card text-black bg-warning h-100">
                        <div className="card-body ">
                            <div className="rotate">
                                <i className="fa fa-lightbulb fa-4x"></i>
                            </div>
                            <h6 className="text"><b>Future Implementation!</b></h6>
                           <p>This Placeholder can be use to add any  action in  future</p>
                        </div>
                    </div>
                </div>


                </div>

                
               
               </div>
               <div>
         <h1 className="event-title">EVENTS</h1>
        <BootstrapTable data={ this.state.data }  pagination options={ this.options } className="event-table">
        <TableHeaderColumn  dataField='button'   dataFormat={this.buttonFormatter.bind(this)} className="event-table-th" >Action</TableHeaderColumn>
        <TableHeaderColumn dataField='event_id' isKey className="event-table-th">Event ID</TableHeaderColumn>
        <TableHeaderColumn dataField='month' filter={ { type: 'TextFilter', delay: 1000 } } className="event-table-th">Month</TableHeaderColumn>
        <TableHeaderColumn dataField='base_location' filter={ { type: 'TextFilter', delay: 1000 } } className="event-table-th">BaseLocation</TableHeaderColumn>
        <TableHeaderColumn dataField='council_name' filter={ { type: 'TextFilter', delay: 1000 } } className="event-table-th">CouncilName</TableHeaderColumn>
        <TableHeaderColumn dataField='beneficiary_name' filter={ { type: 'TextFilter', delay: 1000 } } className="event-table-th">BeneficiaryName</TableHeaderColumn>
      </BootstrapTable>
            </div>
            
            </div>
        )
    }
}
export default Event