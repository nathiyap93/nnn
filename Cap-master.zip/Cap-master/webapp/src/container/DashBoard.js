import React from 'react';
import Axios from 'axios';
import {connect} from 'react-redux';
import './DashBoard.css';

class DashBoard extends React.Component{
    constructor(props){
        super(props);
        console.log("props in dashboard",this.props);
        this.state = {
            totalEvents:0,
            livesImpacted:0,
            totalVolunteers:0,
            totalParticipants:0
        }
    }

    
   
    
    componentDidMount = () => {
        // const transport = Axios.create({
        //     withCredentials: true
        //   })
        //console.log('componentDidMount called in dashboard',this.props.history.location.user.token);
        console.log("token:", `Bearer ${this.props.Users.token}`);
        
        // let  header = {
        //     Authorization: "Bearer "+this.props.history.location.user.token,
        //,'Authorization': `Bearer ${this.props.history.location.user.token}` { withCredentials: true , credentials: 'same-origin'},
           
        Axios.get('http://localhost:9040/dashboard/', { headers: {'Content-Type': 'application/json','Authorization': `Bearer ${this.props.Users.token}`}}).then(res =>{
          console.log("res val:",res);
          console.log("res:",res.data);
          if(res.status=='200'){
              this.setState({totalEvents:res.data.totalEvents})
              this.setState({livesImpacted:res.data.livesImpacted})
              this.setState({totalVolunteers:res.data.totalVolunteers})
              this.setState({totalParticipants: res.data.totalParticipants})
          }
          }).catch(function (error) {
            console.log("error:",error);
          });
        
    }
    
    render(){ console.log("propss",this.props);
        return(
            <div>
                              
          
          <div className="dashboard-row mb-3">
                <div className="col-xl-3 col-sm-6 py-2">
                    <div className="card bg-success text-white h-100">
                        <div className="card-body bg-success">
                            <div className="rotate">
                                <i className="fa fa-desktop fa-4x"></i>
                            </div>
                            <h6 className="text-uppercase">Total Events</h6>
                         <h1 className="display-4">{this.state.totalEvents}</h1>
                        </div>
                    </div>
                </div>
         

         
                <div className="col-xl-3 col-sm-6 py-2">
                <div className="card text-white bg-danger h-100">
                        <div className="card-body bg-danger">
                            <div className="rotate">
                                <i className="fa fa-link fa-4x"></i>
                            </div>
                            <h6 className="text-uppercase">Lives impacted</h6>
                            <h1 className="display-4">{this.state.livesImpacted}</h1>
                        </div>
                    </div>
                </div>

                <div className="col-xl-3 col-sm-6 py-2">
                <div className="card text-white bg-info h-100">
                        <div className="card-body bg-info">
                            <div className="rotate">
                                <i className="fa fa-user fa-4x"></i>
                            </div>
                            <h6 className="text-uppercase">Total Volunteers</h6>
                             <h1 className="display-4">{this.state.totalVolunteers}</h1>
                        </div>
                    </div>
                </div>

                
                <div className="col-xl-3 col-sm-6 py-2">
                <div className="card text-white bg-warning h-100">
                        <div className="card-body">
                            <div className="rotate">
                                <i className="fa fa-user fa-4x"></i>
                            </div>
                            <h6 className="text-uppercase">Total Participants</h6>
                            <h1 className="display-4">{this.state.totalParticipants}</h1>
                        </div>
                    </div>
                </div>

                </div>
          {/* </div> */}
          </div>
        )
    }
}
const   mapStateToProps = state =>{
    return {
        Users:state.userData
        
    };
   };
   export default connect(mapStateToProps,null) (DashBoard);
