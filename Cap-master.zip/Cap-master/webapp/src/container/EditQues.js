import React from 'react';
class EditQues extends React.Component{
    render(){
        return(
            <div>
                 <h1 className="event-title">Edit Question</h1>
            </div>
        )
    }
}
export default EditQues;