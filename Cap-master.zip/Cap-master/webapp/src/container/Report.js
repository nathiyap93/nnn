import React from 'react';
import Aux from '../component/Aux';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table-plus';
import Axios from 'axios';
class Report extends React.Component{
    constructor(props){
     super(props);
     this.options = {
        defaultSortName: 'base_location',  // default sort column name
        defaultSortOrder: 'desc'  // default sort order
      };
     this.state={
        data:[]
     }
    }

    componentDidMount = () => {
      //console.log('componentDidMount called in dashboard',this.props.history.location.user.token);
      // let  header = {
      //     Authorization: "Bearer "+this.props.history.location.user.token,
      
         
        Axios.get('http://localhost:9040/event/', { headers: {'Content-Type': 'application/json'}}).then(res =>{
        console.log("res val:",res);
        console.log("res:",res.data);
        if(res.status=='200'){
         this.reportTableHandler(res.data)
            
        }
        }).catch(function (error) {
          console.log("error:",error);
        });
      
  }

  reportTableHandler =(reportdata)=>{
   reportdata.filter((report) =>{
        console.log("val:",report.body);
        console.log("eventid:",report.body.eventId);
         this.state.data.push(report.body)
        
        return(
         report
       
        )
     })
     this.setState({data:this.state.data})
  }
    render(){ console.log("event propss",this.props);
        return(
            <div>
                 <h1 className="event-title">ACTIONS</h1>
                 <div className="event-row mb-3">

<div className="col-xl-3 col-sm-6 py-2">
 <div className="card text-white bg-info h-100">
         <div className="card-body bg-info">
             <div className="rotate">
                 <i className="fa fa-envelope fa-4x"></i>
             </div>
             <h6 className="text"><b>Email Report!</b></h6>
             <p>Emmployee ID <input type="text" placeholder="Enter Email Address"/>
             <a href="#" class="btn btn-primary">Send Email</a></p>
         </div>
     </div>
 </div>

 <div className="col-xl-3 col-sm-6 py-2">
 <div className="card text-black bg-warning h-100">
         <div className="card-body ">
             <div className="rotate">
                 <i className="fa fa-lightbulb fa-4x"></i>
             </div>
             <h6 className="text"><b>Future Implementation!</b></h6>
            <p>This Placeholder can be use to add any  action in  future</p>
         </div>
     </div>
 </div>


 </div>


                <div>

            </div>

            <div>
         <h1 className="event-title">EVENT  REPORTS</h1>
        <BootstrapTable data={ this.state.data }  pagination options={ this.options }>
        <th dataField='view' className="event-table-th">Action</th>
        <TableHeaderColumn dataField='event_id'  isKey filter={ { type: 'TextFilter', delay: 1000 } } className="event-table-th">Event ID</TableHeaderColumn>
        <th dataField='month' filter={ { type: 'TextFilter', delay: 1000 } } className="event-table-th">Month</th>
        <TableHeaderColumn dataField='base_location' filter={ { type: 'TextFilter', delay: 1000 } } className="event-table-th">BaseLocation</TableHeaderColumn>
        <TableHeaderColumn dataField='council_name' filter={ { type: 'TextFilter', delay: 1000 } } className="event-table-th">CouncilName</TableHeaderColumn>
        <TableHeaderColumn dataField='beneficiary_name' filter={ { type: 'TextFilter', delay: 1000 } } className="event-table-th">BeneficiaryName</TableHeaderColumn>
      </BootstrapTable>
            </div>
            </div>
        )
    }
}
export default Report