import React from 'react';

class AddQues extends React.Component {
    render() {
        return (
            <div style={{ borderBottom: "1px solid", paddingBottom: "15px" }}>
                <h1 className="event-title">Add Question</h1>
                <div>
                    <label style={{ paddingRight: "130px", paddingLeft: "15px" }}>Feedback Type</label>
                    <input type="radio" value="participated" name="participated" style={{ margin: "5px" }} />participated
                    <input type="radio" value="Not participated" style={{ margin: "5px" }} />Not participated
                    <input type="radio" value="Unregistered" style={{ margin: "5px" }} />Unregistered <br />
                    <label style={{ margin: "5px", paddingTop: "10px" }}>
                        <input type="checkbox" style={{ margin: "10px" }} />Allow Multiple Answers <br />
                        <input type="checkbox" style={{ margin: "10px" }} />Free text Answers <br />
                        <input type="checkbox" style={{ margin: "10px" }} />Custom Question <br /></label> <br />
                    <div> <label style={{ paddingLeft: "15px", paddingRight: "120px" }}> Question</label>  <input type="text" style={{ width: "60%" }} placeholder="Description (required)" /></div>
                    <div> <label style={{ paddingLeft: "15px", paddingRight: "66px" }}><button className="add-ans-button">ADD ANSWER</button> </label><input type="text" placeholder="type answer" style={{ width: "60%" }} /></div> <br /><br />
                    <div style={{ paddingLeft: "340px" }}>  <button className="save-ans-button">SAVE</button>
                        <button className="cancel-ans-button">CANCEL</button>
                        <button className="delete-ans-button">DELETE</button></div>
                </div>
            </div>
        )
    }
}

export default AddQues;