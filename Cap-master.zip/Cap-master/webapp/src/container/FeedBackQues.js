import React from 'react';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table-plus';
import Axios from 'axios';
class feedBackQues extends React.Component{
    constructor(props){
        super(props);
        this.state={
            data:[]
        }
    }

    buttonFormatter=(cell, row)=>{
        console.log("row",row.eventId);
        
      return <button  className="btn btn-primary" onClick={this.editQuestionhandler.bind(this)} >EDIT</button>;
    }

    addQuestionHandler=()=>{
        this.props.history.push({pathname: '/add-question'})
    }
    editQuestionHandler=()=>{
        this.props.history.push({pathname: '/edit-question'})
    }

    componentDidMount = () => {
        //console.log('componentDidMount called in dashboard',this.props.history.location.user.token);
        // let  header = {
        //     Authorization: "Bearer "+this.props.history.location.user.token,
        
           
          Axios.get('http://localhost:8081/question', { headers: {'Content-Type': 'application/json'}}).then(res =>{
          console.log("res val:",res);
          console.log("res:",res.data);
          if(res.status=='200'){
           this.ansTableHandler(res.data)
              
          }
          }).catch(function (error) {
            console.log("error:",error);
          });
        
    }
    ansTableHandler =(quesdata)=>{
        quesdata.filter((ques) =>{
             console.log("val:",ques.body);
             console.log("question:",ques.body.question);
              this.state.data.push(ques.body)
             
             return(
                ques
            
             )
          })
          this.setState({data:this.state.data})
          console.log("data",this.state.data);
          
       }

    render(){
        return(
            <div>
                <div >
                <h1 className="event-title">FEEDBACK QUESTIONS</h1>
                <div style={{padding:"5px",float:"right"}}><button className="add-pmo-button" onClick={this.addQuestionHandler.bind(this)}>+ Add Question</button></div>
                <div className="add-pmo">
                <BootstrapTable data={ this.state.data }  pagination options={ this.options }>
                    <TableHeaderColumn dataField='question' className="event-table-th">Question</TableHeaderColumn>
                    <TableHeaderColumn dataField='totalAns' isKey className="event-table-th">Total Answer</TableHeaderColumn>
                    <TableHeaderColumn dataField='feedback_type'  className="event-table-th">Feedback Type</TableHeaderColumn>
                    <TableHeaderColumn  dataField='button'   dataFormat={this.buttonFormatter.bind(this)} className="event-table-th">Action</TableHeaderColumn>
                </BootstrapTable>
                </div>
            </div> 
            </div>
        );
    }
}

export default feedBackQues;