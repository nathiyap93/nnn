package com.fms.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import com.fms.model.Answers;

public interface AnswersRepository extends ReactiveCrudRepository<Answers, Integer> {

}