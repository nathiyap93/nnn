package com.fms.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import com.fms.model.Questions;

public interface QuestionsRepository extends ReactiveCrudRepository<Questions, Integer> {

	// @Query("select * from questions where id = ?queId")
	// Mono<Questions> findById(String queId);

}